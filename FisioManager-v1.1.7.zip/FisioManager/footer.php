<footer class="text-center text-white fixed-bottom">
  <!-- Grid container -->
  <div class="text-center p-3" style="background: linear-gradient(90deg, #bfc1c3,  #dddddd );">
    © 2021 Copyright:
    <span class="text-white">Todos os direitos reservados a FabricaWeb</span>
    <span class="text-muted" style="float: right;">VERSÃO 1.1.7</span>
  </div>
  <!-- Copyright -->
</footer>		
<!-- script references -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js/popper.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<script type="text/javascript" src="node_modules/chart.js/dist/chart.min.js"></script>
<script type="text/javascript" src="node_modules/cleave.js/dist/cleave.min.js"></script>
<script type="text/javascript" src="js/bootbox.min.js"></script>
<script type="text/javascript" src="js/jquery.mask.js"></script>
<script type="text/javascript" src="js/pace.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
 <!--Load the AJAX API-->






